// PascalCasing
function Message() {
  // JSX: Javascript XML
  const name = "Mosh";
  return <h1>hello {name} </h1>;
}

export default Message;
