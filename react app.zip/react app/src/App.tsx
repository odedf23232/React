import ListGroup from "./components/ListGroup";

function App() {
  return (
    <div>
      <ListGroup />
    </div>
  );
}

export default App;
